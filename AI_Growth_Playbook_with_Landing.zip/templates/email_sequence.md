# Secvență Email (5 în 7 zile)
