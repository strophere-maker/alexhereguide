# 10 Scripturi TikTok/Shorts
